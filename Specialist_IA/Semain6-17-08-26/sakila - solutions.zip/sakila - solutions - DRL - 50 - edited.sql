------------------------------
---------- SAKILA ------------
----------- DRL --------------
------------------------------
USE sakila;
GO

----------------
-- Exercice 1 --
----------------
SELECT first_name, last_name 
FROM actor;

----------------
-- Exercice 2 --
----------------
SELECT actor_id, first_name, last_name 
FROM actor 
WHERE first_name = 'William';

----------------
-- Exercice 3 --
----------------
SELECT UPPER(CONCAT(first_name, ' ', last_name)) AS 'Nom d''acteur' 
FROM actor;

----------------
-- Exercice 4 --
----------------
SELECT first_name, last_name 
FROM customer 
WHERE active = 1;

----------------
-- Exercice 5 --
----------------
SELECT * 
FROM film 
WHERE title != 'GREASE YOUTH';

----------------
-- Exercice 6 --
----------------
SELECT actor_id, first_name, last_name 
FROM actor
WHERE last_name like '%GEN%';

----------------
-- Exercice 7 --
----------------
SELECT actor_id, last_name, first_name 
FROM actor 
WHERE last_name like '%LI%'
ORDER BY last_name, first_name;

----------------
-- Exercice 8 --
----------------
SELECT country_id, country 
FROM country 
WHERE country IN ('Afghanistan', 'Bangladesh', 'China');

----------------
-- Exercice 9 --
----------------
SELECT TOP (5)*
FROM film 
WHERE [description] LIKE '%Woman%';

-----------------
-- Exercice 10 --
-----------------
SELECT title,
	length / 60 as 'Duree en heures',
	length % 60 AS 'Duree en minutes'	
FROM film
ORDER BY 'Duree en heures' desc, 'Duree en minutes' desc;

-----------------
-- Exercice 11 --
-----------------
SELECT * 
FROM film 
WHERE special_features LIKE '%commentaries%' 
ORDER BY rental_duration;

-----------------
-- Exercice 12 --
-----------------
SELECT * 
FROM rental 
WHERE rental_date BETWEEN '2005-05-20' AND '2005-05-25' 
ORDER BY rental_date DESC;

-----------------
-- Exercice 13 --
-----------------
SELECT title 
FROM film 
WHERE title NOT LIKE 'a%';

-----------------
-- Exercice 14 --
-----------------
SELECT *
FROM FILM
WHERE release_year != 2005;

-----------------
-- Exercice 15 --
-----------------
SELECT * 
FROM customer 
WHERE create_date NOT BETWEEN '2006-02-13' AND '2006-02-14';

-----------------
-- Exercice 16 --
-----------------
SELECT * 
FROM film 
WHERE (film_id between 0 and 10 OR LENGTH > 180) AND (rating='PG');

-----------------
-- Exercice 17 --
-----------------
SELECT A.first_name, A.last_name 
FROM actor AS A 
	JOIN film_actor AS FA ON A.actor_id = FA.actor_id
	JOIN film AS F ON F.film_id = FA.film_id
WHERE last_name LIKE 'Johansson' AND title ='CASPER DRAGONFLY';

-----------------
-- Exercice 18 --
-----------------
SELECT C.first_name, C.last_name, A.address, A.address2
FROM customer AS C
	JOIN address AS A ON C.address_id = A.address_id;

-----------------
-- Exercice 19 --
-----------------
SELECT CONCAT(C.first_name, ' ', C.last_name) AS 'customer', P.amount
FROM payment AS p
	JOIN customer AS c ON P.customer_id = C.customer_id
WHERE amount > 10;

-----------------
-- Exercice 20 --
-----------------
SELECT C.first_name, C.last_name
FROM customer AS C
	JOIN address AS A ON C.address_id = A.address_id
WHERE postal_code IN (45844, 43331, 65750);

-----------------
-- Exercice 21 --
-----------------
SELECT COUNT(DISTINCT last_name) AS 'nbr_nom_famille'
FROM actor;

-----------------
-- Exercice 22 --
-----------------
SELECT A.first_name, A.last_name, F.title
FROM film_actor AS FA
	JOIN actor AS A ON FA.actor_id = A.actor_id
	JOIN film AS F ON FA.film_id = F.film_id;

-----------------
-- Exercice 23 --
-----------------
SELECT TOP(5) last_name, COUNT(*) AS 'nombre_acteurs'  
FROM actor 
GROUP BY last_name 
ORDER BY COUNT(*) DESC;

-----------------
-- Exercice 24 --
-----------------
SELECT last_name, COUNT(*) AS 'number_actors'
FROM actor 
GROUP BY last_name 
HAVING count(*) >= 2;

-----------------
-- Exercice 25 --
-----------------
SELECT ST.store_id, 
	CONCAT(SF.first_name, ' ', SF.last_name) AS 'nom_manager',
	A.address,
	C.city
FROM store AS ST
	JOIN staff AS SF ON ST.manager_staff_id = SF.staff_id
	JOIN address AS A ON ST.address_id = A.address_id
	JOIN city AS C ON A.city_id = C.city_id;

-----------------
-- Exercice 26 --
-----------------
/*
SELECT L.name, COUNT(*) AS 'nombre_films'
FROM film AS F
	FULL JOIN language AS L on L.language_id= F.language_id
GROUP BY L.name
HAVING COUNT(*) > 1
UNION
SELECT L.name, COUNT(*)
FROM film AS F
	FULL JOIN language AS L on L.language_id= F.language_id
GROUP BY L.name
HAVING COUNT(*) <= 1;
*/
-- version corrigée
WITH 
q as (
	SELECT L.name, F.film_id
	FROM film AS F
	FULL JOIN language AS L on L.language_id= F.language_id
	GROUP BY L.name, F.film_id
	)
SELECT q.name , COUNT(DISTINCT q.film_id)AS 'nombre_films'
FROM q
GROUP BY q.name

-----------------
-- Exercice 27 --
-----------------
SELECT * FROM staff WHERE picture IS NULL;

-----------------
-- Exercice 28 --
-----------------
SELECT COUNT(*) AS 'nombre_films'
FROM film WHERE rental_duration > 5;

-----------------
-- Exercice 29 --
-----------------
SELECT AVG([length]) AS 'duree _moyenne'
FROM film; 

-----------------
-- Exercice 30 --
-----------------
SELECT count(*) AS 'films_voyages'
FROM inventory
	JOIN film ON film.film_id = inventory.film_id
WHERE title like '%VOYAGE%';

-----------------
-- Exercice 31 --
-----------------
SELECT first_name, SUM(amount) AS 'total_oayements', count(amount) AS 'nombre_payments'
FROM customer 
	JOIN payment ON payment.customer_id = customer.customer_id 
WHERE first_name='MARGARET'
GROUP BY first_name;

-----------------
-- Exercice 32 --
-----------------
SELECT C.customer_id, 
	CONVERT(DECIMAL(5,2), AVG(P.amount)) AS 'montant_moyen'
FROM customer AS C
	JOIN payment AS P ON P.customer_id = C.customer_id
GROUP BY C.customer_id
HAVING AVG(amount) > (SELECT AVG(amount) FROM payment);

-----------------
-- Exercice 33 --
-----------------
/*
-- Montant moyen par client
SELECT customer_id, AVG(amount) AS 'montant_moyen_client'
FROM payment
GROUP BY customer_id;

-- Montant moyen par magasin
SELECT S.store_id, AVG(P.amount) AS 'montant_moyen_magasin'
FROM store AS S
	JOIN customer AS C ON S.store_id = C.store_id
	JOIN payment AS P ON C.customer_id = P.customer_id
GROUP BY S.store_id;
*/

SELECT C.customer_id, AVG(P.amount) AS 'montant_moyen_client', S_AVG.montant_moyen_magasin
FROM payment AS P
	JOIN customer AS C ON P.customer_id = C.customer_id
	JOIN (
		SELECT S.store_id, AVG(P.amount) AS 'montant_moyen_magasin'
		FROM store AS S
			JOIN customer AS C ON S.store_id = C.store_id
			JOIN payment AS P ON C.customer_id = P.customer_id
		GROUP BY S.store_id
	) AS S_AVG ON C.store_id = S_AVG.store_id
GROUP BY C.customer_id, S_AVG.montant_moyen_magasin
HAVING AVG(P.amount) > S_AVG.montant_moyen_magasin;


WITH q as 
(
SELECT S.store_id, AVG(P.amount) AS 'montant_moyen_magasin'
		FROM store AS S
			JOIN customer AS C ON S.store_id = C.store_id
			JOIN payment AS P ON C.customer_id = P.customer_id
		GROUP BY S.store_id
)
SELECT C.customer_id, AVG(P.amount) AS 'montant_moyen_client', q.montant_moyen_magasin
FROM payment AS P
	JOIN customer AS C ON P.customer_id = C.customer_id
	JOIN q ON C.store_id = q.store_id
GROUP BY C.customer_id, q.montant_moyen_magasin
HAVING AVG(P.amount) > q.montant_moyen_magasin;



-----------------
-- Exercice 34 --
-----------------
SELECT MIN(amount) FROM payment
WHERE customer_id = 1;

-----------------
-- Exercice 35 --
-----------------
SELECT TOP(1) A.first_name, A.last_name, COUNT(*) AS 'nombre_films'
FROM film_actor AS FA
	JOIN actor AS A ON FA.actor_id = A.actor_id
GROUP BY FA.actor_id, A.first_name, A.last_name
ORDER BY COUNT(*) DESC;

-----------------
-- Exercice 36 --
-----------------
SELECT title
FROM film
WHERE title LIKE 'C%' OR title LIKE 'W%'
	AND title IN (
		SELECT title
		FROM film
		WHERE language_id = 1
	);

-----------------
-- Exercice 37 --
-----------------
-- avec une sous-requête
SELECT TOP(10) C.customer_id, SUM(P.amount) AS 'montant'
FROM customer AS C
	JOIN payment AS P ON C.customer_id = P.customer_id
WHERE active = 1 AND store_id = (
	SELECT ST.store_id
	FROM store AS ST
		JOIN staff AS SF ON ST.manager_staff_id = SF.staff_id
	WHERE SF.first_name = 'Mike' AND SF.last_name = 'Hillyer'
)
GROUP BY C.customer_id
ORDER BY SUM(P.amount) DESC;

-- avec une jointure
SELECT TOP(10) C.customer_id, SUM(P.amount) AS 'montant'
FROM customer AS C
	JOIN payment AS P ON C.customer_id = P.customer_id
	JOIN staff AS S ON C.store_id = S.store_id
WHERE S.first_name = 'Mike' AND S.last_name = 'Hillyer'
GROUP BY C.customer_id
ORDER BY SUM(P.amount) DESC;

-----------------
-- Exercice 38 --
-----------------
SELECT inventory_id, 'disponible' AS 'statut_magasin1'
FROM rental
WHERE return_date IS NOT NULL AND inventory_id IN (
	SELECT inventory_id
	FROM inventory
	WHERE store_id = 1 AND film_id = (
		SELECT film_id
		FROM film
		WHERE title = 'Academy Dinosaur'
	)
)
GROUP BY inventory_id;

-----------------
-- Exercice 39 --
-----------------
SELECT title, film_id 
FROM film
WHERE film_id NOT IN (
	SELECT film_id 
	FROM rental AS R 
		JOIN inventory AS I ON R.inventory_id = I.film_id
);

-----------------
-- Exercice 40 --
-----------------
SELECT c.[name] as 'catégorie', AVG([length]) as 'durée moyenne'
FROM film f 
	JOIN film_category fc on f.film_id = fc.film_id
	JOIN category c on c.category_id = fc.category_id
GROUP BY c.[name];

-----------------
-- Exercice 41 --
-----------------
SELECT CONCAT(first_name, ' ', last_name)
FROM actor a
WHERE EXISTS (
	SELECT actor_id 
	FROM film_actor fa
	WHERE fa.actor_id = a.actor_id
)

-----------------
-- Exercice 42 --
-----------------
SELECT DISTINCT [actors]
FROM film_list
WHERE category = 'Horror';

SELECT DISTINCT a.first_name, a.last_name
FROM film f
	JOIN film_category fc ON f.film_id = fc.film_id
	JOIN category c ON fc.category_id = c.category_id
	JOIN film_actor fa ON f.film_id = fa.film_id
	JOIN actor a ON fa.actor_id = a.actor_id
WHERE c.[name] = 'Horror';

-----------------
-- Exercice 43 --
-----------------
SELECT  
	(
		SELECT CONCAT(first_name, ' ', last_name) 
		FROM staff st 
		WHERE st.staff_id = s.staff_id
	) as 'nom employé', 
	SUM(amount) as 'montant appelé'
FROM payment p
	JOIN staff s ON p.staff_id = s.staff_id
WHERE YEAR(payment_date) = 2005 AND MONTH(payment_date) = 8
GROUP BY s.staff_id

-----------------
-- Exercice 44 --
-----------------
SELECT title, COUNT(*) as 'nombre d acteurs'
FROM film f
	JOIN film_actor fa ON f.film_id = fa.film_id
GROUP BY title;

-----------------
-- Exercice 45 --
-----------------
SELECT DISTINCT CONCAT(first_name, ' ', last_name)
FROM film f
	JOIN film_actor fa ON f.film_id = fa.film_id
	JOIN actor a ON fa.actor_id = a.actor_id
WHERE fa.film_id IN (
        SELECT fa.film_id
        FROM film_actor fa
        WHERE actor_id = (
                SELECT actor_id
                FROM actor
                WHERE first_name = 'Penelope' AND last_name = 'Guiness'
            )
	)
	AND fa.actor_id != (
		SELECT actor_id
		FROM actor
		WHERE first_name = 'Penelope' AND last_name = 'Guiness'
	)

-- alt
WITH 
q1 as (
		SELECT actor_id
        FROM actor
        WHERE first_name = 'Penelope' AND last_name = 'Guiness'
	)
,q2 as (

        SELECT fa.film_id
        FROM film_actor fa
        WHERE actor_id in (SELECT * FROM q1)
	) 
SELECT DISTINCT CONCAT(first_name, ' ', last_name) as [nom complet d'acteur ayant joué avec P.G.]
FROM film f
	JOIN film_actor fa ON f.film_id = fa.film_id
	JOIN actor a ON fa.actor_id = a.actor_id
WHERE fa.film_id IN (SELECT * FROM q2)
	AND fa.actor_id NOT IN (SELECT * FROM q1)
-----------------
-- Exercice 46 --
-----------------
SELECT email 
FROM customer c
	JOIN [address] a ON c.address_id = a.address_id 
	JOIN city ct ON a.city_id = ct.city_id
	JOIN country co ON co.country_id = ct.country_id
WHERE co.country_id = (
	select country_id 
	FROM country 
	WHERE country = 'canada'
)

-----------------
-- Exercice 47 --
-----------------
SELECT title, rating 
FROM film
WHERE rating IN ('G', 'PG')

-- Alt
WITH
q1 as (
	SELECT c.category_id
	FROM category c
	WHERE c.name LIKE 'FAMILY'
	)
,q2 as (
	SELECT fc.film_id
	FROM film_category fc
	WHERE fc.category_id IN (SELECT * FROM q1)
	)
SELECT f.title, f.rating
FROM film f
WHERE f.film_id in (SELECT * FROM q2)


-----------------
-- Exercice 48 --
-----------------
SELECT title, COUNT(rental_id)
FROM film f
	JOIN inventory i ON f.film_id = i.film_id
	JOIN rental r ON r.inventory_id = i.inventory_id
GROUP BY title
ORDER BY COUNT(rental_id) DESC

-----------------
-- Exercice 49 --
-----------------
SELECT category_id, [name], (
	SELECT CONCAT(first_name, ' ', last_name)
	FROM actor
	WHERE actor_id = 
	(
		SELECT TOP(1) fa.actor_id
		FROM film f
		JOIN film_actor fa ON f.film_id = fa.film_id
		JOIN film_category fc ON fc.film_id = f.film_id
		WHERE fc.category_id = cat.category_id
		GROUP BY fa.actor_id
		ORDER BY COUNT(fa.actor_id) DESC
	)
)
FROM category cat

-----------------
-- Exercice 50 --
-----------------
SELECT TOP (5) [category]
      ,[total_sales]
  FROM [sakila].[dbo].[sales_by_film_category]
  ORDER BY total_sales DESC

  
-- sans les "Views"/"Vues"
WITH q as 
(
SELECT fc.category_id , SUM(p.amount) as sum_sales
FROM film_category as fc
LEFT JOIN film as f ON f.film_id = fc.film_id
LEFT JOIN inventory i  on i.film_id = f.film_id
LEFT JOIN rental r on r.inventory_id = i.inventory_id
LEFT JOIN payment p on p.rental_id = r.rental_id
GROUP BY fc.category_id 
)
SELECT c.name,q.*
FROM q
LEFT JOIN category c ON c.category_id = q.category_id
ORDER BY c.name