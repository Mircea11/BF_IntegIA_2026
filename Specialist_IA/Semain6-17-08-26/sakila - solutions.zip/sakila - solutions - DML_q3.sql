USE master
GO

USE sakila
GO


DECLARE @TransactionName VARCHAR(20) = 'Transaction3';  
BEGIN TRANSACTION @TransactionName



-------------------------
-- EXERCICE SAKILA DML --
-------------------------


/* ex 3
Ajoutez dans l�inventaire de votre magasin 3 exemplaires d�un film de votre choix.
*/

/*
ajouter � l'inventaire = table d'associassion

-selectionner 3 id existants de la table de film
-selectionner id de notre store

- inserer dans l'inventaire
*/


SELECT TOP(3) *
FROM film

SELECT *
FROM store

SELECT TOP(3) *
FROM inventory

INSERT INTO inventory (film_id,store_id,last_update) VALUES
(1,3,GETDATE())
,(2,3,GETDATE())
,(3,3,GETDATE())

SELECT TOP(5)*
FROM inventory
ORDER BY last_update DESC

COMMIT TRANSACTION @TransactionName -- Remplacer ROLLBACK avec COMMIT 

GO

SELECT TOP(5)*
FROM inventory
ORDER BY last_update DESC