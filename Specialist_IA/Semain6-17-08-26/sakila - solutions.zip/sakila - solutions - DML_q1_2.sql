USE master
GO

USE sakila
GO


DECLARE @TransactionName VARCHAR(20) = 'Transaction2';  
BEGIN TRANSACTION @TransactionName



-------------------------
-- EXERCICE SAKILA DML --
-------------------------


/* ex 1 & 2
Ajoutez un nouveau magasin avec vous comme g�rant.
Votre adresse et celle de votre magasin doivent �tre diff�rentes.
*/

/*
ajouter � store
-> besoin d'une adresse (du magasin): ici on va en r�utiliser une
-> besoin d'un staff

ajouter � staff
-> besoin d'une adresse (du staff): ici on va en r�utiliser une
-> besoin d'un store: circularit� de r�f�rences
	--> drop une des deux contraintes pour insertion, puis r�ajout contraintes
*/

/*


SELECT *
FROM [address]
*/
--ALTER TABLE store ADD COLUMN store_id INT 
ALTER TABLE store DROP CONSTRAINT fk_store_staff
ALTER TABLE staff DROP CONSTRAINT fk_staff_store

INSERT INTO store (manager_staff_id,address_id,last_update) VALUES
(3 , (SELECT MAX([address_id]) AS [address_id] FROM [address] ),GETDATE())


-- besoin d'ajouter un staff avec id = 3 maintenant (autoincr�ment�)
INSERT INTO staff (
					first_name
					,last_name
					,address_id
					,email
					,store_id
					,active
					,username
					,password
					,last_update) VALUES

(
	'Alpha'
	,'Lambda'
	,(SELECT MIN([address_id]) as [address_id] FROM [address])
	, 'alpha.lambda@email.com'
	, (SELECT MAX(store_id) as [store_id] FROM store)
	, 1
	, 'Alpha'
	, 'p455w0rd'
	, GETDATE()
)

SELECT * 
FROM store

SELECT *
FROM staff


ALTER TABLE store ADD CONSTRAINT fk_store_staff FOREIGN KEY (manager_staff_id) REFERENCES staff (staff_id)
ALTER TABLE staff ADD CONSTRAINT fk_staff_store FOREIGN KEY (store_id) REFERENCES store (store_id)

COMMIT TRANSACTION @TransactionName -- Remplacer ROLLBACK avec COMMIT 

SELECT *
FROM store

SELECT * 
FROM staff
GO